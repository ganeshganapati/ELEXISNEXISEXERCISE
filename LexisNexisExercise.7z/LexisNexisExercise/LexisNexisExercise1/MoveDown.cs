﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexisNexisExercise1
{
    class MoveDown : IMovable
    {
        public string Move()
        {
            return "Basic Down Move";
        }
    }
}
