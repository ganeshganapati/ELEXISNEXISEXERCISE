﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexisNexisExercise1
{
    class FactoryObject
    {
        public static IMovable GetObject(string typeOfObject) 
        {
            IMovable obj = null;
            if (typeOfObject == "Up")
            {
                obj = new MoveUp();

            }
            else if (typeOfObject == "Down")
            {
                obj = new MoveDown();
            }
            else if (typeOfObject == "Left")
            {
                obj = new MoveLeft();
            }
            else if (typeOfObject == "Right")
            {
                obj = new MoveRight();
            }
            else  
            {
                obj = new MoveCombo();
            }
             
            
            return obj;
    }
    }
}
