﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexisNexisExercise1
{
    class MoveCombo : IMovable 
    {

        public string Move()
        {
            IMovable objup = FactoryObject.GetObject("Up");
            IMovable objdown = FactoryObject.GetObject("Down");

            return objup.Move() + objup.Move() + objdown.Move() + objdown.Move() + "Combo Move";


        }
    }
}
