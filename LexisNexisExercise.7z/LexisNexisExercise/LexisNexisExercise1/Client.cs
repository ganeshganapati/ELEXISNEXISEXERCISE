﻿using LexisNexisExercise1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLexiNexiTest
{
   public class Client
    {
        public string DoMove(string move)
        {
            IMovable obj = FactoryObject.GetObject(move);
            return obj.Move();

        }
    }
}
