﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexisNexisExercise2
{
    [Serializable]
    public class ExpenditureProhibitedException : Exception
    {

        public ExpenditureProhibitedException()
        { }

        public ExpenditureProhibitedException(string message)
            : base(message)
        { }

        public ExpenditureProhibitedException(string message, Exception innerException)
            : base(message, innerException)
        { }

    }
    
}
