﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexisNexisExercise2
{
    [Serializable]
    public class ExceededSizeException : Exception
    {
        public ExceededSizeException()
        { }

        public ExceededSizeException(string message)
            : base(message)
        { }

        public ExceededSizeException(string message, Exception innerException)
            : base(message, innerException)
        { }
    }
}
