﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexisNexisExercise2
{
    public class Stack<T>
    {
        #region member
        private T[] stackArray;
        private int maximumLength;
        public int Size { get; private set; }
        #endregion

        public Stack(int lenghth)
        {
            #region Constructor
            //TODO:IMPLEMEMT ME
            maximumLength = lenghth;
            stackArray = new T[lenghth];
            #endregion
        }
        public void Push(T value)
        {
            if (Size == maximumLength) throw new ExceededSizeException("Exceeded Size Exception");
            stackArray[Size++] = value;
        }
        public T Pop()
        {
            //TODO:IMPLEMEMT ME
            if (Size == 0) throw new ExpenditureProhibitedException("Expenditur eProhibited Exception");
            return stackArray[--Size];
        }
        public T Peek()
        {
            //TODO:IMPLEMEMT ME
            if (Size == 0) throw new ExpenditureProhibitedException();
            return stackArray[Size - 1];
        }
    }
   
}
