﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LexisNexisExercise2;

namespace LexisNexisTest
{
    [TestClass]
    public class StackTest
    {
       
            [TestMethod]
            public void Creation()
            {
                Stack<int> s = new Stack<int>(3);
                Assert.AreEqual(0, s.Size);
            }

            [TestMethod]
            public void Push_Pop()
            {
                Stack<int> s = new Stack<int>(3);
                s.Push(1);
                s.Push(2);
                s.Push(3);
                int value = s.Pop();
                Assert.AreEqual(3, value);
                Assert.AreEqual(2, s.Size);
            }

            [TestMethod]
            [ExpectedException(typeof(ExpenditureProhibitedException), "ExpenditureProhibitedException")]
            public void Too_Much_Pop()
            {
                Stack<int> s = new Stack<int>(3);
                s.Push(1);
                s.Push(2);
                s.Pop();
                s.Pop();
                s.Pop();
                s.Pop();
                
            }

            [TestMethod]
            [ExpectedException(typeof(ExceededSizeException), "Exceeded Size Exception")]
            public void Too_Much_Push()
            {
                Stack<int> s = new Stack<int>(3);
               
                s.Push(1);
                s.Push(2);
                s.Push(3);
                s.Push(4);
                
            }

            [TestMethod]
            [ExpectedException(typeof(ExpenditureProhibitedException), "Expenditur eProhibited Exception")]
            public void Peek_Exception()
            {
                Stack<int> s = new Stack<int>(3);
                s.Peek();
                
            }

            [TestMethod]
            public void Peek_Element()
            {
                Stack<int> s = new Stack<int>(3);
                s.Push(1);
                s.Push(2);
                int value = s.Peek();
                Assert.AreEqual(2, value);
                Assert.AreEqual(2, s.Size);
            }
        }

    
}
