﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LexisNexisExercise1;
using FLexiNexiTest;

namespace LexisNexisTest
{
    [TestClass]
    public class DoMoveTest
    {
        [TestMethod]
        public void DoMove_Up()
        {
            Client objClient = new Client();
            objClient.DoMove("Up");
            Assert.AreEqual("Basic Up Move", objClient.DoMove("Up"));           
            
        }
        [TestMethod]
        public void DoMove_Down()
        {
            Client objClient = new Client();
            objClient.DoMove("Down");
            Assert.AreEqual("Basic Down Move", objClient.DoMove("Down"));

        }
        [TestMethod]
        public void DoMove_Left()
        {
            Client objClient = new Client();
            objClient.DoMove("Left");
            Assert.AreEqual("Basic Left Move", objClient.DoMove("Left"));

        }

        [TestMethod]
        public void DoMove_Right()
        {
            Client objClient = new Client();
            objClient.DoMove("Right");
            Assert.AreEqual("Basic Right Move", objClient.DoMove("Right"));

        }
        [TestMethod]
        public void DoMove_Combo()
        {
            Client objClient = new Client();
            objClient.DoMove("Combo");
            Assert.AreEqual("Basic Up MoveBasic Up MoveBasic Down MoveBasic Down MoveCombo Move", objClient.DoMove("Combo"));

        }
    }
}
