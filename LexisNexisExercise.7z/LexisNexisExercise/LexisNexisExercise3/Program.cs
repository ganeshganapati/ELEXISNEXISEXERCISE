﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LexisNexisExercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            DirectoryFileSplitterUtlity obj = new DirectoryFileSplitterUtlity(@"C:\TEST");
            obj.Splitter();
            Console.WriteLine(obj.Directory.ToString());
            Console.WriteLine(obj.File.ToString());

 
        }

        

       
    }
}
