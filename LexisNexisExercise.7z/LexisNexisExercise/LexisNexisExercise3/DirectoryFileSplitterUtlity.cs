﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.IO.Path;


namespace LexisNexisExercise3
{
    class DirectoryFileSplitterUtlity
    {
        private readonly string validFullPath;
        private int length;
        private int rootLength;
        private bool pivotFound;
        public string Directory { get; set; }
        public string File { get; set; }

        public DirectoryFileSplitterUtlity(string validFullPath)
    {
        this.validFullPath = validFullPath;
        length = validFullPath.Length;
        rootLength = GetRootLength(validFullPath);
    }

        private int GetRootLength(string validFullPath)
        {
            return 10;
        }

        public void Splitter()
        {
            if (validFullPath != null)
            {
                IgnoreTrailingSlash();

                FindPivotIndexBetweenEndOfStringAndRoot();

                if (!pivotFound)
                    TrimmmedDirectory();
            }
        }

        // no pivot, return just the trimmed directory
        private void TrimmmedDirectory()
        {
            Directory = validFullPath.Substring(0, length);
        }

        // find the pivot index between end of string and root
        private void FindPivotIndexBetweenEndOfStringAndRoot()
        {
            for (int pivot = length - 1; pivot >= rootLength; pivot--)
            {
                if (IsDirectorySeparator(validFullPath[pivot]))
                {
                    Directory = validFullPath.Substring(0, pivot);
                    File = validFullPath.Substring(pivot + 1, length - pivot - 1);
                    pivotFound = true;
                }
            }
        }

        private bool IsDirectorySeparator(char p)
        {
            throw new NotImplementedException();
        }

        // ignore a trailing slash
        private void IgnoreTrailingSlash()
        {
            if (length > rootLength && EndsInDirectorySeparator(validFullPath))
                length--;
        }

        private bool EndsInDirectorySeparator(string validFullPath)
        {
            return true;
        }
    }
}
